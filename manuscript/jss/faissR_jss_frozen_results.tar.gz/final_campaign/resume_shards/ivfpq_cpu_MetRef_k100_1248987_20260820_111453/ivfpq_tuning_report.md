# ivfpq Tuning Report

Generated: 2026-08-20 13:16:34 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## IVFPQ Notes

- Rows tune FAISS IVF-PQ `ivf_nlist`, `ivf_nprobe`, `pq_m`, and fixed 8-bit PQ codes; Euclidean and raw inner product use native FAISS IVF-PQ L2/IP, while cosine/correlation use normalized L2 transforms.
- CUDA rows exercise the public `backend = "cuda", method = "ivfpq"` route, which resolves to FAISS GPU IVF-PQ with cuVS-enabled FAISS builds when available.
- CUDA correlation rows call the public `backend = "cuda", method = "ivfpq", metric = "correlation"` route, which row-centers and row-normalizes float32 data before FAISS GPU IVF-PQ search and converts normalized-search distances back to correlation distance.
- CUDA IVFPQ correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_ivfpq_correlation_shape_tuning_defaults_from_uploaded_results.csv` after aggregating the measured `faissR_IVFPQ_TUNING_CUDA_correlation_20260703_095008` sweep.
- CUDA IVFPQ raw-inner-product defaults are initially summarized in `benchmark_scripts/cuda_ivfpq_inner_product_shape_tuning_defaults_from_seeded_euclidean_results.csv`, seeded from the measured CUDA IVFPQ Euclidean rows and marked validation-pending until the dedicated inner-product sweep replaces them.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-recall candidate below target is recorded as a best-available setting.
- `nlist` controls the number of coarse IVF lists, `nprobe` controls how many lists are searched, and `pq_m` controls product-quantizer subdivision. Larger `nprobe` and larger feasible `pq_m` generally improve recall but can increase build/search time and GPU memory traffic.

## Status Counts


 failed success timeout 
     21     887     124 
