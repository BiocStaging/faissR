# vamana Tuning Report

Generated: 2026-08-18 04:30:03 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## Vamana Notes

- CPU and CUDA rows tune the native faissR Vamana-style robust-pruning degree `vamana_r`, search breadth `vamana_search_l`, and robust-pruning `vamana_alpha`.
- CUDA rows call the public `backend = "cuda", method = "vamana"` route, which keeps the Vamana pruning rule and uses the native CUDA row-candidate refinement kernel.
- CUDA cosine rows row-normalize the float32 input, run normalized Euclidean Vamana refinement, and convert distances back to cosine distance.
- CUDA correlation rows row-center and row-normalize the float32 input before the same CUDA Vamana refinement; CUDA raw-inner-product rows use shifted dot-product ordering. Current package defaults for both CUDA correlation and CUDA raw inner product are seeded from the measured CUDA cosine Vamana table until their metric-specific sweeps are rerun.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-recall candidate below target is recorded as a best-available setting.

## Status Counts


success timeout 
    448      56 
