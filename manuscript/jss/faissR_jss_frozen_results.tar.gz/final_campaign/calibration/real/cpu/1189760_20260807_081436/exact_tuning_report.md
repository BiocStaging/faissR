# exact Tuning Report

Generated: 2026-08-17 00:46:46 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## Status Counts


success timeout 
    279      81 
