# nndescent Tuning Report

Generated: 2026-08-09 12:18:02 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## NN-descent Notes

- CPU rows tune native NN-descent candidate pool size, iteration count, maximum candidate breadth, and random-projection seed count.
- CUDA rows tune direct cuVS NN-descent `graph_degree`, `intermediate_graph_degree`, and `max_iterations`.
- CUDA cosine rows call the public `backend = "cuda", method = "nndescent", metric = "cosine"` route, which row-normalizes to float32 before cuVS NN-descent and converts normalized Euclidean distances back to cosine distance.
- CUDA correlation rows call the public `backend = "cuda", method = "nndescent", metric = "correlation"` route, which row-centers and row-normalizes to float32 before cuVS NN-descent and converts normalized Euclidean distances back to correlation distance.
- CUDA NN-descent correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_nndescent_correlation_shape_tuning_defaults_from_seeded_euclidean_results.csv`; these rows are validation-pending until a metric-specific CUDA correlation sweep replaces the Euclidean-seeded policy.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-recall candidate below target is recorded as a best-available setting.

## Status Counts


success timeout 
    330      30 
