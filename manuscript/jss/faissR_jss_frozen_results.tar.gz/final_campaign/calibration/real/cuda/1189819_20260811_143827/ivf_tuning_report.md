# ivf Tuning Report

Generated: 2026-08-12 20:51:34 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## IVF Notes

- Rows tune FAISS IVF-Flat `ivf_nlist` and `ivf_nprobe`; Euclidean and raw inner product use native FAISS IVF L2/IP, while cosine/correlation use normalized FAISS IVF searches.
- CUDA rows exercise the public `backend = "cuda", method = "ivf"` route, which resolves to FAISS GPU IVF-Flat with cuVS-enabled FAISS builds when available.
- CUDA correlation rows call the public `backend = "cuda", method = "ivf", metric = "correlation"` route, which row-centers and row-normalizes float32 data before FAISS GPU IVF search and converts normalized-search distances back to correlation distance.
- CUDA IVF correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_ivf_correlation_shape_tuning_defaults_from_uploaded_results.csv` after aggregating the measured `faissR_IVF_TUNING_CUDA_correlation_20260703_133655` sweep.
- CUDA IVF raw-inner-product defaults are initially summarized in `benchmark_scripts/cuda_ivf_inner_product_shape_tuning_defaults_from_seeded_euclidean_results.csv`, seeded from the measured CUDA IVF Euclidean rows and marked validation-pending until the dedicated inner-product sweep replaces them.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-coverage best-available candidate is recorded with `tuning_benchmark_target_met = FALSE`.

## Status Counts


 failed success timeout 
     38     240      46 
