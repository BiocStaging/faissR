# bruteforce Tuning Report

Generated: 2026-08-08 12:37:57 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## Bruteforce Notes

- Rows tune exhaustive brute-force search metadata rather than an approximate recall/speed trade-off; recall should be exact apart from metric transforms and numerical precision.
- CPU rows tune FAISS Flat query batching and fitted-index reuse for Euclidean, cosine, correlation, and raw inner-product bruteforce routes.
- CUDA rows tune cuVS brute-force query batch size, resource reuse, and float32 output handling for Euclidean, cosine, and correlation routes.
- CUDA correlation rows call the public `backend = "cuda", method = "bruteforce", metric = "correlation"` route, which row-centers and row-normalizes float32 data before cuVS L2 brute-force search and converts normalized Euclidean distances back to correlation distance.
- CUDA Bruteforce correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_bruteforce_correlation_shape_tuning_defaults_from_proxy_results.csv`; these rows initially reuse measured Euclidean cuVS brute-force batch/resource choices because the earlier uploaded correlation sweep failed before reaching the backend.

## Status Counts


success 
    432 
