# exact Tuning Report

Generated: 2026-08-09 20:48:05 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## Status Counts


success 
    432 
