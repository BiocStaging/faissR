# cagra Tuning Report

Generated: 2026-08-10 02:56:46 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## CAGRA Notes

- CUDA rows tune CAGRA graph construction and search parameters: `cagra_build_algo`, `cagra_graph_degree`, `cagra_intermediate_graph_degree`, `cagra_search_width`, and `cagra_itopk_size`.
- `cagra_build_algo` is a cuVS CAGRA builder choice (`auto`, `ivf_pq`, `nn_descent`, or `iterative_cagra_search`), not a fallback to a different public faissR method.
- CUDA Euclidean shape/k/target defaults are summarized in `benchmark_scripts/cuda_cagra_euclidean_shape_tuning_defaults_from_uploaded_results.csv` after aggregating the measured CAGRA sweep.
- CUDA cosine rows call the public `backend = "cuda", method = "cagra", metric = "cosine"` route, which row-normalizes the float32 input, runs Euclidean CAGRA graph search, and converts normalized Euclidean distances back to cosine distance.
- CUDA correlation rows call the public `backend = "cuda", method = "cagra", metric = "correlation"` route, which row-centers and row-normalizes the float32 input, runs Euclidean CAGRA graph search, and converts normalized Euclidean distances back to correlation distance.
- CUDA raw-inner-product rows call the public `backend = "cuda", method = "cagra", metric = "inner_product"` route, which applies the maximum-inner-product-to-L2 extra-dimension transform, runs CAGRA graph search, and converts distances back to faissR's shifted inner-product convention.
- CUDA CAGRA correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_cagra_correlation_shape_tuning_defaults_from_seeded_euclidean_results.csv`; these rows are validation-pending until a metric-specific CUDA correlation sweep replaces the Euclidean-seeded policy.
- CUDA CAGRA raw-inner-product shape/k/target defaults are summarized in `benchmark_scripts/cuda_cagra_inner_product_shape_tuning_defaults_from_seeded_euclidean_results.csv`; these rows are validation-pending until `run_hpc_cagra_tuning_cuda_inner_product.sh` replaces the Euclidean-seeded policy.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-recall candidate below target is recorded as a best-available setting.
- If a metric-specific sweep failed before reaching the backend, any seeded defaults must be marked with `tuning_benchmark_target_met = FALSE` until the corrected sweep is rerun.

## Status Counts


 failed success timeout 
     48    1092      12 
