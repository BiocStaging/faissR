# hnsw Tuning Report

Generated: 2026-08-08 05:46:42 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## HNSW Notes

- CPU rows tune FAISS HNSW `M`, `efConstruction`, and `efSearch` for Euclidean, cosine, correlation, and raw inner-product routes.
- CUDA rows tune the cuVS HNSW-from-CAGRA route through `cagra_graph_degree`, `cagra_intermediate_graph_degree`, and `hnsw_ef_search`.
- CUDA correlation rows call the public `backend = "cuda", method = "hnsw", metric = "correlation"` route, which row-centers and row-normalizes float32 data before cuVS HNSW graph search and converts normalized Euclidean distances back to correlation distance.
- CUDA raw-inner-product rows call the public `backend = "cuda", method = "hnsw", metric = "inner_product"` route, which applies the maximum-inner-product-to-L2 transform before cuVS HNSW graph search and converts distances back to raw inner-product scores.
- CUDA HNSW correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_hnsw_correlation_shape_tuning_defaults_from_uploaded_results.csv` after aggregating the measured `faissR_HNSW_TUNING_CUDA_correlation_20260703_070901` sweep.
- CUDA HNSW raw-inner-product defaults are initially seeded from `benchmark_scripts/cuda_hnsw_inner_product_shape_tuning_defaults_from_seeded_euclidean_results.csv`; this wrapper replaces those validation-pending rows with measured metric-specific settings.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest candidate that reaches the requested recall target when available; otherwise the highest-recall candidate below target is recorded as a best-available setting.

## Status Counts


 failed success 
     60     660 
