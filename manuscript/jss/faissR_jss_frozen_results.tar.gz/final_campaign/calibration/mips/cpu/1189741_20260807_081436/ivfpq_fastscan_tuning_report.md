# ivfpq_fastscan Tuning Report

Generated: 2026-08-07 15:54:24 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## IVFPQ FastScan Notes

- CPU rows tune FAISS `IndexIVFPQFastScan` `ivf_nlist`, `ivf_nprobe`, `pq_m`, fixed 4-bit PQ, `ivfpq_fastscan_refine_factor`, and `ivfpq_fastscan_bbs`; Euclidean and raw inner product use native FastScan L2/IP, while cosine/correlation use normalized L2 transforms.
- CUDA rows tune `ivf_nlist`, `ivf_nprobe`, byte-aligned 4-bit `cuvs_ivfpq_pq_dim`, and `FAISSR_CUVS_IVF_BATCH_SIZE`.
- CUDA cosine rows call the public `backend = "cuda", method = "ivfpq_fastscan", metric = "cosine"` route, which row-normalizes to float32 before cuVS IVF-PQ L2 search and converts distances back to cosine distance.
- CUDA correlation rows call the public `backend = "cuda", method = "ivfpq_fastscan", metric = "correlation"` route, which row-centers and row-normalizes to float32 before cuVS IVF-PQ L2 search and converts distances back to correlation distance.
- CUDA raw-inner-product rows call the public `backend = "cuda", method = "ivfpq_fastscan", metric = "inner_product"` route, which applies the maximum-inner-product-to-L2 extra-dimension transform before cuVS IVF-PQ L2 search and converts distances back to shifted inner-product distances.
- CUDA IVFPQ FastScan correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_ivfpq_fastscan_correlation_shape_tuning_defaults_from_seeded_euclidean_results.csv`; these rows are validation-pending until the corrected correlation sweep replaces the prior run that failed before reaching cuVS.
- CUDA IVFPQ FastScan raw-inner-product shape/k/target defaults are summarized in `benchmark_scripts/cuda_ivfpq_fastscan_inner_product_shape_tuning_defaults_from_seeded_euclidean_results.csv`; these rows are validation-pending until this metric-specific sweep replaces the seeded Euclidean policy.
- For cuVS 4-bit IVF-PQ, `pq_dim` is repaired to a byte-aligned value when needed; smaller `pq_dim` and smaller `nprobe` are expected to be faster but can reduce recall.
- `nlist` controls the IVF build/search balance; too few lists can hurt recall, while too many lists can increase build and coarse-search overhead.
- `FAISSR_CUVS_IVF_BATCH_SIZE` changes query batching and GPU memory use, not the IVF-PQ recall target directly.
- faissR submits multi-query cuVS IVF-PQ/FastScan searches in batches and prevents row-by-row search for multi-query calls.
- CUDA host-device traffic columns (`dataset_residency`, `query_residency`, `query_device_cache_status`, `query_host_to_device_copies`) show whether searches reused GPU-resident buffers or uploaded query data.

## Status Counts


success 
    864 
