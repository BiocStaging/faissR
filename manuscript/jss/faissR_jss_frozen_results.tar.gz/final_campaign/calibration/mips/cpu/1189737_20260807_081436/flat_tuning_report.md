# flat Tuning Report

Generated: 2026-08-07 11:29:07 SAST

References are loaded from max-k dataset-folder files created by benchmark_precompute_exact_references.R for each metric and cropped to the requested k.

## Flat Notes

- Rows tune exhaustive FAISS Flat search metadata rather than an approximate recall/speed trade-off; recall should be exact apart from metric transforms and numerical precision.
- CPU rows tune FAISS Flat query batching and fitted-index reuse for Euclidean, cosine, correlation, and raw inner-product routes.
- CUDA rows tune FAISS GPU Flat query batch size, resource reuse, and float32 output handling for Euclidean, cosine, and correlation routes.
- CUDA correlation rows call the public `backend = "cuda", method = "flat", metric = "correlation"` route, which row-centers and row-normalizes float32 data before FAISS GPU Flat L2 search and converts normalized Euclidean distances back to correlation distance.
- Shape-level defaults for `tuning = "auto"` are selected from the fastest measured candidate for each shape/k/target cell; exact methods record `tuning_benchmark_target_met` so any numerical shortfall is visible.
- CUDA Flat correlation shape/k/target defaults are summarized in `benchmark_scripts/cuda_flat_correlation_shape_tuning_defaults_from_uploaded_results.csv` after aggregating the measured FAISS GPU Flat correlation sweep.

## Status Counts


success 
    480 
