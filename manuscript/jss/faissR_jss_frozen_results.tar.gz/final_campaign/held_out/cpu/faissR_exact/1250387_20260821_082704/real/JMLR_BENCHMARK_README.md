# JMLR Benchmark Evidence

This benchmark is designed to answer the manuscript-review concerns about speed evidence, method/library boundaries, autotuning provenance, validation, and GPU-resident KNN output.

## Configuration

- Backend file: `cpu`.
- Metrics: `correlation`.
- k values: `15`, `30`, `50`, `100`.
- Target recall tiers for faissR methods: `0.99`.
- Threads: `12`.
- Timeout per method/dataset/k/metric/target combination: `2000` seconds.
- Input manifest: `/scratch/firenze/NN/Data/float32_dataset_manifest_jmlr.csv`.
- Singularity image recorded by launcher: ``.

## Output Files

- `jmlr_tuned_benchmark_results.csv`: full per-combination result table.
- `jmlr_tuned_benchmark_failures.csv`: failed, skipped, timeout, or not-standalone rows with error text.
- `jmlr_repeated_run_summary.csv`: medians, timing IQRs, held-out-seed recall, and all-run target attainment.
- `jmlr_best_robust_by_dataset_backend_metric_k_target.csv`: fastest method only after the target is met in every measured run.
- `jmlr_ranked_speed_recall.csv`: successful rows ranked by recall, rank correlation, distance error, speed, and memory.
- `jmlr_best_by_dataset_backend_metric_k_target.csv`: best method per dataset/backend/metric/k/target recall block.
- `jmlr_faissr_vs_external_speed.csv`: fastest faissR row versus fastest external package row only where both complete all expected runs and reach the same recall tier.
- `faissR_backend_info.csv`, `faissR_nn_capabilities_runtime.csv`, and `sessionInfo.txt`: reproducibility metadata.

## Interpretation Rules

- Exact methods are still evaluated against the exact subset reference; exactness is also recorded in result metadata when faissR reports it.
- External package rows are not assigned faissR target-recall tiers; they are run once per dataset/metric/k.
- Every raw row records the implementation version, exact call parameters, allocated threads, requested threads, and threading scope.
- GPU-resident `nn_gpu()` rows record search time separately from `host_copy_sec`, so downstream CUDA pipelines can report no-copy timing while quality evaluation remains possible.
- A low-recall fast method is not considered the best in the quality-aware ranking.
- Unsupported metric/backend/provider combinations are failure evidence, not silent fallbacks.
