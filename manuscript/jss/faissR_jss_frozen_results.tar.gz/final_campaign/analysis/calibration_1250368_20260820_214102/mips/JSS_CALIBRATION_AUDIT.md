# JSS calibration audit

Recommendation files: 21.
Candidate-result files: 21.
Latest policy cells: 2880.
Target-meeting cells: 2354.
Below-target successful cells: 526.
Failed policy cells: 0.
Missing expected cells: 0.

No below-target or incomplete cell is eligible for automatic approximate-method promotion.
