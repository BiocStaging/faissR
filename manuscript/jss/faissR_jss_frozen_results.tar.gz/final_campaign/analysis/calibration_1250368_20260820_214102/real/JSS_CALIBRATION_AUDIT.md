# JSS calibration audit

Recommendation files: 84.
Candidate-result files: 84.
Latest policy cells: 8310.
Target-meeting cells: 6792.
Below-target successful cells: 1518.
Failed policy cells: 0.
Missing expected cells: 762.

No below-target or incomplete cell is eligible for automatic approximate-method promotion.
