# Independently tuned CPU HNSW comparison

Validation route runs: 720/720.
Successful cold route runs: 720.
Successful fitted route runs: 720.
Target-equivalent provider pairs: 63/72.
Target-equivalent fitted provider pairs: 63/72.
Each provider configuration was selected using calibration seed 20260706 and evaluated with independent seed 20260807. Cold, fitted-build, and fitted-query times are distinct measured phases; no fitted time is inferred from a cold-call subtraction.
